<?php
echo"welcome to the stage where we are ready to get connected to a database<br>";
$servername="localhost";
$username="root";
$password="";
$database="DBSDP";
// create a connection
$conn = mysqli_connect($servername,$username,$password,$database);
//die if connection was not successful
if(!$conn){
    die("sorry we failed to connect:".mysqli_connect_error());
}
else{
    echo"connect was successful<br>";
}
//create a table in the php
$sql="CREATE TABLE 'php'('sno' INT(6) NOT NULL AUTO_INCREMENT,'name' VARCHAR(12) NOT NULL,'dest' VARCHAR(6) NOT NULL,PRIMERY KEY('sno'))";
$result=mysqli_query ($conn,$sql);
//check for the database creation success
if($result){
    echo "the table was create successfuly!<br>";
}
else{
    echo "the table was not createed successfully because of this error ---->".mysqli_error($conn);
}
?>